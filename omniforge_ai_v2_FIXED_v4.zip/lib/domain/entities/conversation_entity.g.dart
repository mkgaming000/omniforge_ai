// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'conversation_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ConversationEntityAdapter extends TypeAdapter<ConversationEntity> {
  @override
  final int typeId = 1;

  @override
  ConversationEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ConversationEntity(
      id: fields[0] as String,
      title: fields[1] as String,
      createdAt: fields[2] as DateTime,
      updatedAt: fields[3] as DateTime,
      messages: (fields[4] as List).cast<MessageEntity>(),
      modelConfigs: (fields[5] as List).cast<ModelConfigEntity>(),
      pinned: fields[6] as bool,
      archived: fields[7] as bool,
      folderId: fields[8] as String?,
      tags: (fields[9] as List).cast<String>(),
      systemPrompt: fields[10] as String?,
      summary: fields[11] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, ConversationEntity obj) {
    writer
      ..writeByte(12)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.createdAt)
      ..writeByte(3)
      ..write(obj.updatedAt)
      ..writeByte(4)
      ..write(obj.messages)
      ..writeByte(5)
      ..write(obj.modelConfigs)
      ..writeByte(6)
      ..write(obj.pinned)
      ..writeByte(7)
      ..write(obj.archived)
      ..writeByte(8)
      ..write(obj.folderId)
      ..writeByte(9)
      ..write(obj.tags)
      ..writeByte(10)
      ..write(obj.systemPrompt)
      ..writeByte(11)
      ..write(obj.summary);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ConversationEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
