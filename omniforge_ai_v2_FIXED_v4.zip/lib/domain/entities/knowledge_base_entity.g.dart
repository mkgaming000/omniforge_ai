// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'knowledge_base_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class KnowledgeBaseEntityAdapter extends TypeAdapter<KnowledgeBaseEntity> {
  @override
  final int typeId = 80;

  @override
  KnowledgeBaseEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return KnowledgeBaseEntity(
      id: fields[0] as String,
      name: fields[1] as String,
      embeddingProvider: fields[3] as String,
      documentCount: fields[4] as int,
      createdAt: fields[5] as DateTime,
      updatedAt: fields[6] as DateTime,
      description: fields[2] as String?,
      metadata: (fields[7] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, KnowledgeBaseEntity obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.description)
      ..writeByte(3)
      ..write(obj.embeddingProvider)
      ..writeByte(4)
      ..write(obj.documentCount)
      ..writeByte(5)
      ..write(obj.createdAt)
      ..writeByte(6)
      ..write(obj.updatedAt)
      ..writeByte(7)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is KnowledgeBaseEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
