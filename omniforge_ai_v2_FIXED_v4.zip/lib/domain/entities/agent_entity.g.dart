// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'agent_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class AgentEntityAdapter extends TypeAdapter<AgentEntity> {
  @override
  final int typeId = 70;

  @override
  AgentEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return AgentEntity(
      id: fields[0] as String,
      name: fields[1] as String,
      model: fields[2] as ModelConfigEntity,
      systemPrompt: fields[3] as String,
      createdAt: fields[4] as DateTime,
      description: fields[5] as String?,
      avatar: fields[6] as String?,
      knowledgeBaseId: fields[7] as String?,
      allowedTools: (fields[8] as List).cast<String>(),
      memory: (fields[9] as List).cast<AgentMemoryEntry>(),
      maxIterations: fields[10] as int,
      temperature: fields[11] as double,
      metadata: (fields[12] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, AgentEntity obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.model)
      ..writeByte(3)
      ..write(obj.systemPrompt)
      ..writeByte(4)
      ..write(obj.createdAt)
      ..writeByte(5)
      ..write(obj.description)
      ..writeByte(6)
      ..write(obj.avatar)
      ..writeByte(7)
      ..write(obj.knowledgeBaseId)
      ..writeByte(8)
      ..write(obj.allowedTools)
      ..writeByte(9)
      ..write(obj.memory)
      ..writeByte(10)
      ..write(obj.maxIterations)
      ..writeByte(11)
      ..write(obj.temperature)
      ..writeByte(12)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AgentEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class AgentMemoryEntryAdapter extends TypeAdapter<AgentMemoryEntry> {
  @override
  final int typeId = 71;

  @override
  AgentMemoryEntry read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return AgentMemoryEntry(
      id: fields[0] as String,
      role: fields[1] as AgentRole,
      content: fields[2] as String,
      timestamp: fields[3] as DateTime,
      metadata: (fields[4] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, AgentMemoryEntry obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.role)
      ..writeByte(2)
      ..write(obj.content)
      ..writeByte(3)
      ..write(obj.timestamp)
      ..writeByte(4)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AgentMemoryEntryAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class AgentRoleAdapter extends TypeAdapter<AgentRole> {
  @override
  final int typeId = 72;

  @override
  AgentRole read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return AgentRole.system;
      case 1:
        return AgentRole.user;
      case 2:
        return AgentRole.assistant;
      case 3:
        return AgentRole.tool;
      default:
        return AgentRole.system;
    }
  }

  @override
  void write(BinaryWriter writer, AgentRole obj) {
    switch (obj) {
      case AgentRole.system:
        writer.writeByte(0);
        break;
      case AgentRole.user:
        writer.writeByte(1);
        break;
      case AgentRole.assistant:
        writer.writeByte(2);
        break;
      case AgentRole.tool:
        writer.writeByte(3);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AgentRoleAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
