// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'workspace_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class WorkspaceEntityAdapter extends TypeAdapter<WorkspaceEntity> {
  @override
  final int typeId = 120;

  @override
  WorkspaceEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return WorkspaceEntity(
      id: fields[0] as String,
      name: fields[1] as String,
      path: fields[2] as String,
      createdAt: fields[3] as DateTime,
      description: fields[4] as String?,
      type: fields[5] as WorkspaceType,
      language: fields[6] as String?,
      framework: fields[7] as String?,
      gitUrl: fields[8] as String?,
      cloudSyncEnabled: fields[9] as bool,
      cloudProvider: fields[10] as String?,
      metadata: (fields[11] as Map).cast<String, dynamic>(),
      lastOpenedAt: fields[12] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, WorkspaceEntity obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.path)
      ..writeByte(3)
      ..write(obj.createdAt)
      ..writeByte(4)
      ..write(obj.description)
      ..writeByte(5)
      ..write(obj.type)
      ..writeByte(6)
      ..write(obj.language)
      ..writeByte(7)
      ..write(obj.framework)
      ..writeByte(8)
      ..write(obj.gitUrl)
      ..writeByte(9)
      ..write(obj.cloudSyncEnabled)
      ..writeByte(10)
      ..write(obj.cloudProvider)
      ..writeByte(11)
      ..write(obj.metadata)
      ..writeByte(12)
      ..write(obj.lastOpenedAt);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is WorkspaceEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class WorkspaceTypeAdapter extends TypeAdapter<WorkspaceType> {
  @override
  final int typeId = 101;

  @override
  WorkspaceType read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return WorkspaceType.flutter;
      case 1:
        return WorkspaceType.react;
      case 2:
        return WorkspaceType.vue;
      case 3:
        return WorkspaceType.angular;
      case 4:
        return WorkspaceType.svelte;
      case 5:
        return WorkspaceType.node;
      case 6:
        return WorkspaceType.python;
      case 7:
        return WorkspaceType.rust;
      case 8:
        return WorkspaceType.go;
      case 9:
        return WorkspaceType.java;
      case 10:
        return WorkspaceType.cpp;
      case 11:
        return WorkspaceType.web;
      case 12:
        return WorkspaceType.game;
      case 13:
        return WorkspaceType.general;
      default:
        return WorkspaceType.flutter;
    }
  }

  @override
  void write(BinaryWriter writer, WorkspaceType obj) {
    switch (obj) {
      case WorkspaceType.flutter:
        writer.writeByte(0);
        break;
      case WorkspaceType.react:
        writer.writeByte(1);
        break;
      case WorkspaceType.vue:
        writer.writeByte(2);
        break;
      case WorkspaceType.angular:
        writer.writeByte(3);
        break;
      case WorkspaceType.svelte:
        writer.writeByte(4);
        break;
      case WorkspaceType.node:
        writer.writeByte(5);
        break;
      case WorkspaceType.python:
        writer.writeByte(6);
        break;
      case WorkspaceType.rust:
        writer.writeByte(7);
        break;
      case WorkspaceType.go:
        writer.writeByte(8);
        break;
      case WorkspaceType.java:
        writer.writeByte(9);
        break;
      case WorkspaceType.cpp:
        writer.writeByte(10);
        break;
      case WorkspaceType.web:
        writer.writeByte(11);
        break;
      case WorkspaceType.game:
        writer.writeByte(12);
        break;
      case WorkspaceType.general:
        writer.writeByte(13);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is WorkspaceTypeAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
