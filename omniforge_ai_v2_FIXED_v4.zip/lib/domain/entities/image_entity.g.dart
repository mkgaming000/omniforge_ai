// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'image_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ImageEntityAdapter extends TypeAdapter<ImageEntity> {
  @override
  final int typeId = 10;

  @override
  ImageEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ImageEntity(
      id: fields[0] as String,
      url: fields[1] as String,
      prompt: fields[2] as String,
      provider: fields[3] as AIProvider,
      model: fields[4] as String,
      createdAt: fields[5] as DateTime,
      width: fields[6] as int,
      height: fields[7] as int,
      style: fields[8] as String?,
      negativePrompt: fields[9] as String?,
      seed: fields[10] as int?,
      steps: fields[11] as int?,
      cfgScale: fields[12] as double?,
      thumbnailUrl: fields[13] as String?,
      localPath: fields[14] as String?,
      metadata: (fields[15] as Map).cast<String, dynamic>(),
      folderId: fields[16] as String?,
      collectionIds: (fields[17] as List).cast<String>(),
      favorite: fields[18] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, ImageEntity obj) {
    writer
      ..writeByte(19)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.url)
      ..writeByte(2)
      ..write(obj.prompt)
      ..writeByte(3)
      ..write(obj.provider)
      ..writeByte(4)
      ..write(obj.model)
      ..writeByte(5)
      ..write(obj.createdAt)
      ..writeByte(6)
      ..write(obj.width)
      ..writeByte(7)
      ..write(obj.height)
      ..writeByte(8)
      ..write(obj.style)
      ..writeByte(9)
      ..write(obj.negativePrompt)
      ..writeByte(10)
      ..write(obj.seed)
      ..writeByte(11)
      ..write(obj.steps)
      ..writeByte(12)
      ..write(obj.cfgScale)
      ..writeByte(13)
      ..write(obj.thumbnailUrl)
      ..writeByte(14)
      ..write(obj.localPath)
      ..writeByte(15)
      ..write(obj.metadata)
      ..writeByte(16)
      ..write(obj.folderId)
      ..writeByte(17)
      ..write(obj.collectionIds)
      ..writeByte(18)
      ..write(obj.favorite);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ImageEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class ImageGenerationRequestAdapter
    extends TypeAdapter<ImageGenerationRequest> {
  @override
  final int typeId = 11;

  @override
  ImageGenerationRequest read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ImageGenerationRequest(
      provider: fields[0] as AIProvider,
      model: fields[1] as String,
      prompt: fields[2] as String,
      negativePrompt: fields[3] as String?,
      width: fields[4] as int,
      height: fields[5] as int,
      count: fields[6] as int,
      style: fields[7] as String?,
      seed: fields[8] as int?,
      steps: fields[9] as int?,
      cfgScale: fields[10] as double?,
      referenceImageUrl: fields[11] as String?,
      maskUrl: fields[12] as String?,
      strength: fields[13] as double?,
      responseFormat: fields[14] as String,
      metadata: (fields[15] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, ImageGenerationRequest obj) {
    writer
      ..writeByte(16)
      ..writeByte(0)
      ..write(obj.provider)
      ..writeByte(1)
      ..write(obj.model)
      ..writeByte(2)
      ..write(obj.prompt)
      ..writeByte(3)
      ..write(obj.negativePrompt)
      ..writeByte(4)
      ..write(obj.width)
      ..writeByte(5)
      ..write(obj.height)
      ..writeByte(6)
      ..write(obj.count)
      ..writeByte(7)
      ..write(obj.style)
      ..writeByte(8)
      ..write(obj.seed)
      ..writeByte(9)
      ..write(obj.steps)
      ..writeByte(10)
      ..write(obj.cfgScale)
      ..writeByte(11)
      ..write(obj.referenceImageUrl)
      ..writeByte(12)
      ..write(obj.maskUrl)
      ..writeByte(13)
      ..write(obj.strength)
      ..writeByte(14)
      ..write(obj.responseFormat)
      ..writeByte(15)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ImageGenerationRequestAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
