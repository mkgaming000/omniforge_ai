// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'message_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class MessageEntityAdapter extends TypeAdapter<MessageEntity> {
  @override
  final int typeId = 2;

  @override
  MessageEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return MessageEntity(
      id: fields[0] as String,
      role: fields[1] as MessageRole,
      content: fields[2] as String,
      createdAt: fields[3] as DateTime,
      modelConfig: fields[4] as ModelConfigEntity?,
      status: fields[5] as MessageStatus,
      tokensIn: fields[6] as int,
      tokensOut: fields[7] as int,
      costUsd: fields[8] as double,
      attachments: (fields[9] as List).cast<MessageAttachment>(),
      toolCalls: (fields[10] as List).cast<ToolCall>(),
      toolCallId: fields[11] as String?,
      metadata: (fields[12] as Map).cast<String, dynamic>(),
      error: fields[13] as String?,
      streamingText: fields[14] as String?,
      translations: (fields[15] as Map).cast<String, String>(),
      rating: fields[16] as int?,
    );
  }

  @override
  void write(BinaryWriter writer, MessageEntity obj) {
    writer
      ..writeByte(17)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.role)
      ..writeByte(2)
      ..write(obj.content)
      ..writeByte(3)
      ..write(obj.createdAt)
      ..writeByte(4)
      ..write(obj.modelConfig)
      ..writeByte(5)
      ..write(obj.status)
      ..writeByte(6)
      ..write(obj.tokensIn)
      ..writeByte(7)
      ..write(obj.tokensOut)
      ..writeByte(8)
      ..write(obj.costUsd)
      ..writeByte(9)
      ..write(obj.attachments)
      ..writeByte(10)
      ..write(obj.toolCalls)
      ..writeByte(11)
      ..write(obj.toolCallId)
      ..writeByte(12)
      ..write(obj.metadata)
      ..writeByte(13)
      ..write(obj.error)
      ..writeByte(14)
      ..write(obj.streamingText)
      ..writeByte(15)
      ..write(obj.translations)
      ..writeByte(16)
      ..write(obj.rating);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MessageEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class MessageAttachmentAdapter extends TypeAdapter<MessageAttachment> {
  @override
  final int typeId = 3;

  @override
  MessageAttachment read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return MessageAttachment(
      id: fields[0] as String,
      type: fields[1] as AttachmentType,
      url: fields[2] as String,
      mimeType: fields[3] as String?,
      size: fields[4] as int?,
      name: fields[5] as String?,
      thumbnailUrl: fields[6] as String?,
      metadata: (fields[7] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, MessageAttachment obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.type)
      ..writeByte(2)
      ..write(obj.url)
      ..writeByte(3)
      ..write(obj.mimeType)
      ..writeByte(4)
      ..write(obj.size)
      ..writeByte(5)
      ..write(obj.name)
      ..writeByte(6)
      ..write(obj.thumbnailUrl)
      ..writeByte(7)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MessageAttachmentAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class ToolCallAdapter extends TypeAdapter<ToolCall> {
  @override
  final int typeId = 5;

  @override
  ToolCall read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ToolCall(
      id: fields[0] as String,
      name: fields[1] as String,
      arguments: fields[2] as String,
      result: fields[3] as String?,
      status: fields[4] as ToolCallStatus,
    );
  }

  @override
  void write(BinaryWriter writer, ToolCall obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.arguments)
      ..writeByte(3)
      ..write(obj.result)
      ..writeByte(4)
      ..write(obj.status);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ToolCallAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class MessageRoleAdapter extends TypeAdapter<MessageRole> {
  @override
  final int typeId = 0;

  @override
  MessageRole read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return MessageRole.system;
      case 1:
        return MessageRole.user;
      case 2:
        return MessageRole.assistant;
      case 3:
        return MessageRole.tool;
      case 4:
        return MessageRole.function;
      default:
        return MessageRole.system;
    }
  }

  @override
  void write(BinaryWriter writer, MessageRole obj) {
    switch (obj) {
      case MessageRole.system:
        writer.writeByte(0);
        break;
      case MessageRole.user:
        writer.writeByte(1);
        break;
      case MessageRole.assistant:
        writer.writeByte(2);
        break;
      case MessageRole.tool:
        writer.writeByte(3);
        break;
      case MessageRole.function:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MessageRoleAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class MessageStatusAdapter extends TypeAdapter<MessageStatus> {
  @override
  final int typeId = 8;

  @override
  MessageStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return MessageStatus.pending;
      case 1:
        return MessageStatus.sending;
      case 2:
        return MessageStatus.streaming;
      case 3:
        return MessageStatus.complete;
      case 4:
        return MessageStatus.error;
      case 5:
        return MessageStatus.cancelled;
      default:
        return MessageStatus.pending;
    }
  }

  @override
  void write(BinaryWriter writer, MessageStatus obj) {
    switch (obj) {
      case MessageStatus.pending:
        writer.writeByte(0);
        break;
      case MessageStatus.sending:
        writer.writeByte(1);
        break;
      case MessageStatus.streaming:
        writer.writeByte(2);
        break;
      case MessageStatus.complete:
        writer.writeByte(3);
        break;
      case MessageStatus.error:
        writer.writeByte(4);
        break;
      case MessageStatus.cancelled:
        writer.writeByte(5);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MessageStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class AttachmentTypeAdapter extends TypeAdapter<AttachmentType> {
  @override
  final int typeId = 4;

  @override
  AttachmentType read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return AttachmentType.image;
      case 1:
        return AttachmentType.video;
      case 2:
        return AttachmentType.audio;
      case 3:
        return AttachmentType.file;
      case 4:
        return AttachmentType.code;
      default:
        return AttachmentType.image;
    }
  }

  @override
  void write(BinaryWriter writer, AttachmentType obj) {
    switch (obj) {
      case AttachmentType.image:
        writer.writeByte(0);
        break;
      case AttachmentType.video:
        writer.writeByte(1);
        break;
      case AttachmentType.audio:
        writer.writeByte(2);
        break;
      case AttachmentType.file:
        writer.writeByte(3);
        break;
      case AttachmentType.code:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AttachmentTypeAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class ToolCallStatusAdapter extends TypeAdapter<ToolCallStatus> {
  @override
  final int typeId = 6;

  @override
  ToolCallStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return ToolCallStatus.pending;
      case 1:
        return ToolCallStatus.running;
      case 2:
        return ToolCallStatus.success;
      case 3:
        return ToolCallStatus.error;
      default:
        return ToolCallStatus.pending;
    }
  }

  @override
  void write(BinaryWriter writer, ToolCallStatus obj) {
    switch (obj) {
      case ToolCallStatus.pending:
        writer.writeByte(0);
        break;
      case ToolCallStatus.running:
        writer.writeByte(1);
        break;
      case ToolCallStatus.success:
        writer.writeByte(2);
        break;
      case ToolCallStatus.error:
        writer.writeByte(3);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ToolCallStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
