// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'video_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class VideoEntityAdapter extends TypeAdapter<VideoEntity> {
  @override
  final int typeId = 30;

  @override
  VideoEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return VideoEntity(
      id: fields[0] as String,
      taskId: fields[1] as String,
      prompt: fields[2] as String,
      provider: fields[3] as AIProvider,
      model: fields[4] as String,
      createdAt: fields[5] as DateTime,
      url: fields[6] as String?,
      thumbnailUrl: fields[7] as String?,
      duration: fields[8] as int,
      width: fields[9] as int,
      height: fields[10] as int,
      fps: fields[11] as int,
      status: fields[12] as VideoStatus,
      progress: fields[13] as int,
      error: fields[14] as String?,
      metadata: (fields[15] as Map).cast<String, dynamic>(),
      localPath: fields[16] as String?,
      projectId: fields[17] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, VideoEntity obj) {
    writer
      ..writeByte(18)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.taskId)
      ..writeByte(2)
      ..write(obj.prompt)
      ..writeByte(3)
      ..write(obj.provider)
      ..writeByte(4)
      ..write(obj.model)
      ..writeByte(5)
      ..write(obj.createdAt)
      ..writeByte(6)
      ..write(obj.url)
      ..writeByte(7)
      ..write(obj.thumbnailUrl)
      ..writeByte(8)
      ..write(obj.duration)
      ..writeByte(9)
      ..write(obj.width)
      ..writeByte(10)
      ..write(obj.height)
      ..writeByte(11)
      ..write(obj.fps)
      ..writeByte(12)
      ..write(obj.status)
      ..writeByte(13)
      ..write(obj.progress)
      ..writeByte(14)
      ..write(obj.error)
      ..writeByte(15)
      ..write(obj.metadata)
      ..writeByte(16)
      ..write(obj.localPath)
      ..writeByte(17)
      ..write(obj.projectId);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is VideoEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class VideoGenerationRequestAdapter
    extends TypeAdapter<VideoGenerationRequest> {
  @override
  final int typeId = 31;

  @override
  VideoGenerationRequest read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return VideoGenerationRequest(
      provider: fields[0] as AIProvider,
      model: fields[1] as String,
      prompt: fields[2] as String,
      imageUrl: fields[3] as String?,
      videoUrl: fields[4] as String?,
      duration: fields[5] as int,
      width: fields[6] as int,
      height: fields[7] as int,
      fps: fields[8] as int,
      negativePrompt: fields[9] as String?,
      seed: fields[10] as int?,
      metadata: (fields[11] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, VideoGenerationRequest obj) {
    writer
      ..writeByte(12)
      ..writeByte(0)
      ..write(obj.provider)
      ..writeByte(1)
      ..write(obj.model)
      ..writeByte(2)
      ..write(obj.prompt)
      ..writeByte(3)
      ..write(obj.imageUrl)
      ..writeByte(4)
      ..write(obj.videoUrl)
      ..writeByte(5)
      ..write(obj.duration)
      ..writeByte(6)
      ..write(obj.width)
      ..writeByte(7)
      ..write(obj.height)
      ..writeByte(8)
      ..write(obj.fps)
      ..writeByte(9)
      ..write(obj.negativePrompt)
      ..writeByte(10)
      ..write(obj.seed)
      ..writeByte(11)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is VideoGenerationRequestAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class VideoStatusAdapter extends TypeAdapter<VideoStatus> {
  @override
  final int typeId = 32;

  @override
  VideoStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return VideoStatus.pending;
      case 1:
        return VideoStatus.processing;
      case 2:
        return VideoStatus.complete;
      case 3:
        return VideoStatus.failed;
      case 4:
        return VideoStatus.cancelled;
      default:
        return VideoStatus.pending;
    }
  }

  @override
  void write(BinaryWriter writer, VideoStatus obj) {
    switch (obj) {
      case VideoStatus.pending:
        writer.writeByte(0);
        break;
      case VideoStatus.processing:
        writer.writeByte(1);
        break;
      case VideoStatus.complete:
        writer.writeByte(2);
        break;
      case VideoStatus.failed:
        writer.writeByte(3);
        break;
      case VideoStatus.cancelled:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is VideoStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
