// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'music_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class MusicEntityAdapter extends TypeAdapter<MusicEntity> {
  @override
  final int typeId = 40;

  @override
  MusicEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return MusicEntity(
      id: fields[0] as String,
      prompt: fields[1] as String,
      provider: fields[2] as AIProvider,
      model: fields[3] as String,
      createdAt: fields[4] as DateTime,
      audioUrl: fields[5] as String?,
      title: fields[6] as String?,
      lyrics: fields[7] as String?,
      duration: fields[8] as int,
      tags: (fields[9] as List).cast<String>(),
      style: fields[10] as String?,
      status: fields[11] as MusicStatus,
      metadata: (fields[12] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, MusicEntity obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.prompt)
      ..writeByte(2)
      ..write(obj.provider)
      ..writeByte(3)
      ..write(obj.model)
      ..writeByte(4)
      ..write(obj.createdAt)
      ..writeByte(5)
      ..write(obj.audioUrl)
      ..writeByte(6)
      ..write(obj.title)
      ..writeByte(7)
      ..write(obj.lyrics)
      ..writeByte(8)
      ..write(obj.duration)
      ..writeByte(9)
      ..write(obj.tags)
      ..writeByte(10)
      ..write(obj.style)
      ..writeByte(11)
      ..write(obj.status)
      ..writeByte(12)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MusicEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class MusicGenerationRequestAdapter
    extends TypeAdapter<MusicGenerationRequest> {
  @override
  final int typeId = 42;

  @override
  MusicGenerationRequest read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return MusicGenerationRequest(
      provider: fields[0] as AIProvider,
      model: fields[1] as String,
      prompt: fields[2] as String,
      lyrics: fields[3] as String?,
      title: fields[4] as String?,
      duration: fields[5] as int,
      tags: (fields[6] as List).cast<String>(),
      style: fields[7] as String?,
      instrumental: fields[8] as bool,
      metadata: (fields[9] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, MusicGenerationRequest obj) {
    writer
      ..writeByte(10)
      ..writeByte(0)
      ..write(obj.provider)
      ..writeByte(1)
      ..write(obj.model)
      ..writeByte(2)
      ..write(obj.prompt)
      ..writeByte(3)
      ..write(obj.lyrics)
      ..writeByte(4)
      ..write(obj.title)
      ..writeByte(5)
      ..write(obj.duration)
      ..writeByte(6)
      ..write(obj.tags)
      ..writeByte(7)
      ..write(obj.style)
      ..writeByte(8)
      ..write(obj.instrumental)
      ..writeByte(9)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MusicGenerationRequestAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class MusicStatusAdapter extends TypeAdapter<MusicStatus> {
  @override
  final int typeId = 41;

  @override
  MusicStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return MusicStatus.pending;
      case 1:
        return MusicStatus.processing;
      case 2:
        return MusicStatus.complete;
      case 3:
        return MusicStatus.failed;
      case 4:
        return MusicStatus.streaming;
      default:
        return MusicStatus.pending;
    }
  }

  @override
  void write(BinaryWriter writer, MusicStatus obj) {
    switch (obj) {
      case MusicStatus.pending:
        writer.writeByte(0);
        break;
      case MusicStatus.processing:
        writer.writeByte(1);
        break;
      case MusicStatus.complete:
        writer.writeByte(2);
        break;
      case MusicStatus.failed:
        writer.writeByte(3);
        break;
      case MusicStatus.streaming:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MusicStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
