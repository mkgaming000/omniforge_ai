// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'vector_document_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class VectorDocumentEntityAdapter extends TypeAdapter<VectorDocumentEntity> {
  @override
  final int typeId = 50;

  @override
  VectorDocumentEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return VectorDocumentEntity(
      id: fields[0] as String,
      title: fields[1] as String,
      content: fields[2] as String,
      embedding: (fields[3] as List).cast<double>(),
      createdAt: fields[4] as DateTime,
      source: fields[5] as String?,
      knowledgeBaseId: fields[6] as String?,
      metadata: (fields[7] as Map).cast<String, dynamic>(),
      chunks: (fields[8] as List).cast<DocumentChunkEntity>(),
    );
  }

  @override
  void write(BinaryWriter writer, VectorDocumentEntity obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.content)
      ..writeByte(3)
      ..write(obj.embedding)
      ..writeByte(4)
      ..write(obj.createdAt)
      ..writeByte(5)
      ..write(obj.source)
      ..writeByte(6)
      ..write(obj.knowledgeBaseId)
      ..writeByte(7)
      ..write(obj.metadata)
      ..writeByte(8)
      ..write(obj.chunks);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is VectorDocumentEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class DocumentChunkEntityAdapter extends TypeAdapter<DocumentChunkEntity> {
  @override
  final int typeId = 51;

  @override
  DocumentChunkEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DocumentChunkEntity(
      id: fields[0] as String,
      text: fields[1] as String,
      embedding: (fields[2] as List).cast<double>(),
      startOffset: fields[3] as int?,
      endOffset: fields[4] as int?,
    );
  }

  @override
  void write(BinaryWriter writer, DocumentChunkEntity obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.text)
      ..writeByte(2)
      ..write(obj.embedding)
      ..writeByte(3)
      ..write(obj.startOffset)
      ..writeByte(4)
      ..write(obj.endOffset);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DocumentChunkEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
