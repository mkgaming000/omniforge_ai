// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'orchestrator_entities.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class SharedMemoryEntryAdapter extends TypeAdapter<SharedMemoryEntry> {
  @override
  final int typeId = 210;

  @override
  SharedMemoryEntry read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SharedMemoryEntry(
      id: fields[0] as String,
      agent: fields[1] as OrchestratorAgent,
      key: fields[2] as String,
      value: fields[3] as String,
      timestamp: fields[4] as DateTime,
      kind: fields[5] as MemoryEntryKind,
      metadata: (fields[6] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, SharedMemoryEntry obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.agent)
      ..writeByte(2)
      ..write(obj.key)
      ..writeByte(3)
      ..write(obj.value)
      ..writeByte(4)
      ..write(obj.timestamp)
      ..writeByte(5)
      ..write(obj.kind)
      ..writeByte(6)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SharedMemoryEntryAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class AgentExecutionStateAdapter extends TypeAdapter<AgentExecutionState> {
  @override
  final int typeId = 212;

  @override
  AgentExecutionState read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return AgentExecutionState(
      agent: fields[0] as OrchestratorAgent,
      status: fields[1] as AgentRunStatus,
      startedAt: fields[2] as DateTime,
      completedAt: fields[3] as DateTime?,
      currentTask: fields[4] as String?,
      outputKey: fields[5] as String?,
      error: fields[6] as String?,
      tokenUsage: fields[7] as int,
      modelUsed: fields[8] as String?,
      revisionCount: fields[9] as int,
    );
  }

  @override
  void write(BinaryWriter writer, AgentExecutionState obj) {
    writer
      ..writeByte(10)
      ..writeByte(0)
      ..write(obj.agent)
      ..writeByte(1)
      ..write(obj.status)
      ..writeByte(2)
      ..write(obj.startedAt)
      ..writeByte(3)
      ..write(obj.completedAt)
      ..writeByte(4)
      ..write(obj.currentTask)
      ..writeByte(5)
      ..write(obj.outputKey)
      ..writeByte(6)
      ..write(obj.error)
      ..writeByte(7)
      ..write(obj.tokenUsage)
      ..writeByte(8)
      ..write(obj.modelUsed)
      ..writeByte(9)
      ..write(obj.revisionCount);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AgentExecutionStateAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class OrchestratorAgentAdapter extends TypeAdapter<OrchestratorAgent> {
  @override
  final int typeId = 200;

  @override
  OrchestratorAgent read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return OrchestratorAgent.promptExpander;
      case 1:
        return OrchestratorAgent.taskAnalyzer;
      case 2:
        return OrchestratorAgent.planner;
      case 3:
        return OrchestratorAgent.researcher;
      case 4:
        return OrchestratorAgent.architect;
      case 5:
        return OrchestratorAgent.generator;
      case 6:
        return OrchestratorAgent.codeAgent;
      case 7:
        return OrchestratorAgent.imageAgent;
      case 8:
        return OrchestratorAgent.videoAgent;
      case 9:
        return OrchestratorAgent.audioAgent;
      case 10:
        return OrchestratorAgent.reviewer;
      case 11:
        return OrchestratorAgent.qualityChecker;
      case 12:
        return OrchestratorAgent.securityChecker;
      case 13:
        return OrchestratorAgent.performanceOptimizer;
      case 14:
        return OrchestratorAgent.finalValidator;
      default:
        return OrchestratorAgent.promptExpander;
    }
  }

  @override
  void write(BinaryWriter writer, OrchestratorAgent obj) {
    switch (obj) {
      case OrchestratorAgent.promptExpander:
        writer.writeByte(0);
        break;
      case OrchestratorAgent.taskAnalyzer:
        writer.writeByte(1);
        break;
      case OrchestratorAgent.planner:
        writer.writeByte(2);
        break;
      case OrchestratorAgent.researcher:
        writer.writeByte(3);
        break;
      case OrchestratorAgent.architect:
        writer.writeByte(4);
        break;
      case OrchestratorAgent.generator:
        writer.writeByte(5);
        break;
      case OrchestratorAgent.codeAgent:
        writer.writeByte(6);
        break;
      case OrchestratorAgent.imageAgent:
        writer.writeByte(7);
        break;
      case OrchestratorAgent.videoAgent:
        writer.writeByte(8);
        break;
      case OrchestratorAgent.audioAgent:
        writer.writeByte(9);
        break;
      case OrchestratorAgent.reviewer:
        writer.writeByte(10);
        break;
      case OrchestratorAgent.qualityChecker:
        writer.writeByte(11);
        break;
      case OrchestratorAgent.securityChecker:
        writer.writeByte(12);
        break;
      case OrchestratorAgent.performanceOptimizer:
        writer.writeByte(13);
        break;
      case OrchestratorAgent.finalValidator:
        writer.writeByte(14);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is OrchestratorAgentAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class MemoryEntryKindAdapter extends TypeAdapter<MemoryEntryKind> {
  @override
  final int typeId = 211;

  @override
  MemoryEntryKind read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return MemoryEntryKind.context;
      case 1:
        return MemoryEntryKind.output;
      case 2:
        return MemoryEntryKind.critique;
      case 3:
        return MemoryEntryKind.revision;
      case 4:
        return MemoryEntryKind.toolCall;
      case 5:
        return MemoryEntryKind.apiCall;
      case 6:
        return MemoryEntryKind.error;
      default:
        return MemoryEntryKind.context;
    }
  }

  @override
  void write(BinaryWriter writer, MemoryEntryKind obj) {
    switch (obj) {
      case MemoryEntryKind.context:
        writer.writeByte(0);
        break;
      case MemoryEntryKind.output:
        writer.writeByte(1);
        break;
      case MemoryEntryKind.critique:
        writer.writeByte(2);
        break;
      case MemoryEntryKind.revision:
        writer.writeByte(3);
        break;
      case MemoryEntryKind.toolCall:
        writer.writeByte(4);
        break;
      case MemoryEntryKind.apiCall:
        writer.writeByte(5);
        break;
      case MemoryEntryKind.error:
        writer.writeByte(6);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MemoryEntryKindAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class AgentRunStatusAdapter extends TypeAdapter<AgentRunStatus> {
  @override
  final int typeId = 213;

  @override
  AgentRunStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return AgentRunStatus.queued;
      case 1:
        return AgentRunStatus.running;
      case 2:
        return AgentRunStatus.completed;
      case 3:
        return AgentRunStatus.failed;
      case 4:
        return AgentRunStatus.retrying;
      default:
        return AgentRunStatus.queued;
    }
  }

  @override
  void write(BinaryWriter writer, AgentRunStatus obj) {
    switch (obj) {
      case AgentRunStatus.queued:
        writer.writeByte(0);
        break;
      case AgentRunStatus.running:
        writer.writeByte(1);
        break;
      case AgentRunStatus.completed:
        writer.writeByte(2);
        break;
      case AgentRunStatus.failed:
        writer.writeByte(3);
        break;
      case AgentRunStatus.retrying:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AgentRunStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
