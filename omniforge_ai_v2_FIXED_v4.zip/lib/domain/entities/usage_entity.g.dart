// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'usage_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class UsageEntityAdapter extends TypeAdapter<UsageEntity> {
  @override
  final int typeId = 20;

  @override
  UsageEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return UsageEntity(
      id: fields[0] as String,
      provider: fields[1] as AIProvider,
      model: fields[2] as String,
      timestamp: fields[3] as DateTime,
      tokensIn: fields[4] as int,
      tokensOut: fields[5] as int,
      costUsd: fields[6] as double,
      operation: fields[7] as UsageOperation,
      conversationId: fields[8] as String?,
      metadata: (fields[9] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, UsageEntity obj) {
    writer
      ..writeByte(10)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.provider)
      ..writeByte(2)
      ..write(obj.model)
      ..writeByte(3)
      ..write(obj.timestamp)
      ..writeByte(4)
      ..write(obj.tokensIn)
      ..writeByte(5)
      ..write(obj.tokensOut)
      ..writeByte(6)
      ..write(obj.costUsd)
      ..writeByte(7)
      ..write(obj.operation)
      ..writeByte(8)
      ..write(obj.conversationId)
      ..writeByte(9)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is UsageEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class UsageStatsAdapter extends TypeAdapter<UsageStats> {
  @override
  final int typeId = 22;

  @override
  UsageStats read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return UsageStats(
      totalTokensIn: fields[0] as int,
      totalTokensOut: fields[1] as int,
      totalCostUsd: fields[2] as double,
      totalRequests: fields[3] as int,
      byProvider: (fields[4] as Map).cast<String, ProviderStats>(),
      byDay: (fields[5] as Map).cast<String, DailyStats>(),
      byOperation: (fields[6] as Map).cast<UsageOperation, int>(),
    );
  }

  @override
  void write(BinaryWriter writer, UsageStats obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.totalTokensIn)
      ..writeByte(1)
      ..write(obj.totalTokensOut)
      ..writeByte(2)
      ..write(obj.totalCostUsd)
      ..writeByte(3)
      ..write(obj.totalRequests)
      ..writeByte(4)
      ..write(obj.byProvider)
      ..writeByte(5)
      ..write(obj.byDay)
      ..writeByte(6)
      ..write(obj.byOperation);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is UsageStatsAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class ProviderStatsAdapter extends TypeAdapter<ProviderStats> {
  @override
  final int typeId = 23;

  @override
  ProviderStats read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ProviderStats(
      tokensIn: fields[0] as int,
      tokensOut: fields[1] as int,
      costUsd: fields[2] as double,
      requests: fields[3] as int,
    );
  }

  @override
  void write(BinaryWriter writer, ProviderStats obj) {
    writer
      ..writeByte(4)
      ..writeByte(0)
      ..write(obj.tokensIn)
      ..writeByte(1)
      ..write(obj.tokensOut)
      ..writeByte(2)
      ..write(obj.costUsd)
      ..writeByte(3)
      ..write(obj.requests);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ProviderStatsAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class DailyStatsAdapter extends TypeAdapter<DailyStats> {
  @override
  final int typeId = 24;

  @override
  DailyStats read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DailyStats(
      tokensIn: fields[0] as int,
      tokensOut: fields[1] as int,
      costUsd: fields[2] as double,
      requests: fields[3] as int,
    );
  }

  @override
  void write(BinaryWriter writer, DailyStats obj) {
    writer
      ..writeByte(4)
      ..writeByte(0)
      ..write(obj.tokensIn)
      ..writeByte(1)
      ..write(obj.tokensOut)
      ..writeByte(2)
      ..write(obj.costUsd)
      ..writeByte(3)
      ..write(obj.requests);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DailyStatsAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class UsageOperationAdapter extends TypeAdapter<UsageOperation> {
  @override
  final int typeId = 21;

  @override
  UsageOperation read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return UsageOperation.chat;
      case 1:
        return UsageOperation.streaming;
      case 2:
        return UsageOperation.imageGeneration;
      case 3:
        return UsageOperation.imageEdit;
      case 4:
        return UsageOperation.videoGeneration;
      case 5:
        return UsageOperation.audioTranscription;
      case 6:
        return UsageOperation.textToSpeech;
      case 7:
        return UsageOperation.musicGeneration;
      case 8:
        return UsageOperation.embedding;
      case 9:
        return UsageOperation.fineTuning;
      case 10:
        return UsageOperation.moderation;
      default:
        return UsageOperation.chat;
    }
  }

  @override
  void write(BinaryWriter writer, UsageOperation obj) {
    switch (obj) {
      case UsageOperation.chat:
        writer.writeByte(0);
        break;
      case UsageOperation.streaming:
        writer.writeByte(1);
        break;
      case UsageOperation.imageGeneration:
        writer.writeByte(2);
        break;
      case UsageOperation.imageEdit:
        writer.writeByte(3);
        break;
      case UsageOperation.videoGeneration:
        writer.writeByte(4);
        break;
      case UsageOperation.audioTranscription:
        writer.writeByte(5);
        break;
      case UsageOperation.textToSpeech:
        writer.writeByte(6);
        break;
      case UsageOperation.musicGeneration:
        writer.writeByte(7);
        break;
      case UsageOperation.embedding:
        writer.writeByte(8);
        break;
      case UsageOperation.fineTuning:
        writer.writeByte(9);
        break;
      case UsageOperation.moderation:
        writer.writeByte(10);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is UsageOperationAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
