// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'model_config_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ModelConfigEntityAdapter extends TypeAdapter<ModelConfigEntity> {
  @override
  final int typeId = 7;

  @override
  ModelConfigEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ModelConfigEntity(
      provider: fields[0] as AIProvider,
      modelId: fields[1] as String,
      displayName: fields[2] as String?,
      temperature: fields[3] as double,
      maxTokens: fields[4] as int,
      topP: fields[5] as double,
      frequencyPenalty: fields[6] as double,
      presencePenalty: fields[7] as double,
      stopSequences: (fields[8] as List).cast<String>(),
      stream: fields[9] as bool,
      tools: (fields[10] as List).cast<String>(),
      toolChoice: fields[11] as String?,
      responseFormat: fields[12] as String?,
      seed: fields[13] as int?,
      customHeaders: (fields[14] as Map).cast<String, String>(),
      customParams: (fields[15] as Map).cast<String, dynamic>(),
      costPer1kInput: fields[16] as double,
      costPer1kOutput: fields[17] as double,
      contextWindow: fields[18] as int,
      supportsVision: fields[19] as bool,
      supportsTools: fields[20] as bool,
      supportsStreaming: fields[21] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, ModelConfigEntity obj) {
    writer
      ..writeByte(22)
      ..writeByte(0)
      ..write(obj.provider)
      ..writeByte(1)
      ..write(obj.modelId)
      ..writeByte(2)
      ..write(obj.displayName)
      ..writeByte(3)
      ..write(obj.temperature)
      ..writeByte(4)
      ..write(obj.maxTokens)
      ..writeByte(5)
      ..write(obj.topP)
      ..writeByte(6)
      ..write(obj.frequencyPenalty)
      ..writeByte(7)
      ..write(obj.presencePenalty)
      ..writeByte(8)
      ..write(obj.stopSequences)
      ..writeByte(9)
      ..write(obj.stream)
      ..writeByte(10)
      ..write(obj.tools)
      ..writeByte(11)
      ..write(obj.toolChoice)
      ..writeByte(12)
      ..write(obj.responseFormat)
      ..writeByte(13)
      ..write(obj.seed)
      ..writeByte(14)
      ..write(obj.customHeaders)
      ..writeByte(15)
      ..write(obj.customParams)
      ..writeByte(16)
      ..write(obj.costPer1kInput)
      ..writeByte(17)
      ..write(obj.costPer1kOutput)
      ..writeByte(18)
      ..write(obj.contextWindow)
      ..writeByte(19)
      ..write(obj.supportsVision)
      ..writeByte(20)
      ..write(obj.supportsTools)
      ..writeByte(21)
      ..write(obj.supportsStreaming);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ModelConfigEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
