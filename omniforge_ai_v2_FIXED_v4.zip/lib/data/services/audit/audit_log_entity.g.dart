// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'audit_log_entity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class AuditLogEntryAdapter extends TypeAdapter<AuditLogEntry> {
  @override
  final int typeId = 90;

  @override
  AuditLogEntry read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return AuditLogEntry(
      id: fields[0] as String,
      timestamp: fields[1] as DateTime,
      action: fields[2] as AuditLogAction,
      level: fields[3] as AuditLogLevel,
      message: fields[4] as String,
      userId: fields[5] as String?,
      resourceType: fields[6] as String?,
      resourceId: fields[7] as String?,
      metadata: (fields[8] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, AuditLogEntry obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.timestamp)
      ..writeByte(2)
      ..write(obj.action)
      ..writeByte(3)
      ..write(obj.level)
      ..writeByte(4)
      ..write(obj.message)
      ..writeByte(5)
      ..write(obj.userId)
      ..writeByte(6)
      ..write(obj.resourceType)
      ..writeByte(7)
      ..write(obj.resourceId)
      ..writeByte(8)
      ..write(obj.metadata);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AuditLogEntryAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class AuditLogActionAdapter extends TypeAdapter<AuditLogAction> {
  @override
  final int typeId = 91;

  @override
  AuditLogAction read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return AuditLogAction.login;
      case 1:
        return AuditLogAction.logout;
      case 2:
        return AuditLogAction.apiKeySaved;
      case 3:
        return AuditLogAction.apiKeyDeleted;
      case 4:
        return AuditLogAction.apiKeyUsed;
      case 5:
        return AuditLogAction.conversationCreated;
      case 6:
        return AuditLogAction.conversationDeleted;
      case 7:
        return AuditLogAction.messageSent;
      case 8:
        return AuditLogAction.imageGenerated;
      case 9:
        return AuditLogAction.videoGenerated;
      case 10:
        return AuditLogAction.musicGenerated;
      case 11:
        return AuditLogAction.documentProcessed;
      case 12:
        return AuditLogAction.mcpToolExecuted;
      case 13:
        return AuditLogAction.agentRun;
      case 14:
        return AuditLogAction.fileUploaded;
      case 15:
        return AuditLogAction.fileDownloaded;
      case 16:
        return AuditLogAction.fileDeleted;
      case 17:
        return AuditLogAction.permissionGranted;
      case 18:
        return AuditLogAction.permissionRevoked;
      case 19:
        return AuditLogAction.securityBlocked;
      case 20:
        return AuditLogAction.configChanged;
      case 21:
        return AuditLogAction.dataExported;
      case 22:
        return AuditLogAction.dataDeleted;
      default:
        return AuditLogAction.login;
    }
  }

  @override
  void write(BinaryWriter writer, AuditLogAction obj) {
    switch (obj) {
      case AuditLogAction.login:
        writer.writeByte(0);
        break;
      case AuditLogAction.logout:
        writer.writeByte(1);
        break;
      case AuditLogAction.apiKeySaved:
        writer.writeByte(2);
        break;
      case AuditLogAction.apiKeyDeleted:
        writer.writeByte(3);
        break;
      case AuditLogAction.apiKeyUsed:
        writer.writeByte(4);
        break;
      case AuditLogAction.conversationCreated:
        writer.writeByte(5);
        break;
      case AuditLogAction.conversationDeleted:
        writer.writeByte(6);
        break;
      case AuditLogAction.messageSent:
        writer.writeByte(7);
        break;
      case AuditLogAction.imageGenerated:
        writer.writeByte(8);
        break;
      case AuditLogAction.videoGenerated:
        writer.writeByte(9);
        break;
      case AuditLogAction.musicGenerated:
        writer.writeByte(10);
        break;
      case AuditLogAction.documentProcessed:
        writer.writeByte(11);
        break;
      case AuditLogAction.mcpToolExecuted:
        writer.writeByte(12);
        break;
      case AuditLogAction.agentRun:
        writer.writeByte(13);
        break;
      case AuditLogAction.fileUploaded:
        writer.writeByte(14);
        break;
      case AuditLogAction.fileDownloaded:
        writer.writeByte(15);
        break;
      case AuditLogAction.fileDeleted:
        writer.writeByte(16);
        break;
      case AuditLogAction.permissionGranted:
        writer.writeByte(17);
        break;
      case AuditLogAction.permissionRevoked:
        writer.writeByte(18);
        break;
      case AuditLogAction.securityBlocked:
        writer.writeByte(19);
        break;
      case AuditLogAction.configChanged:
        writer.writeByte(20);
        break;
      case AuditLogAction.dataExported:
        writer.writeByte(21);
        break;
      case AuditLogAction.dataDeleted:
        writer.writeByte(22);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AuditLogActionAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class AuditLogLevelAdapter extends TypeAdapter<AuditLogLevel> {
  @override
  final int typeId = 92;

  @override
  AuditLogLevel read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return AuditLogLevel.debug;
      case 1:
        return AuditLogLevel.info;
      case 2:
        return AuditLogLevel.warning;
      case 3:
        return AuditLogLevel.error;
      case 4:
        return AuditLogLevel.critical;
      default:
        return AuditLogLevel.debug;
    }
  }

  @override
  void write(BinaryWriter writer, AuditLogLevel obj) {
    switch (obj) {
      case AuditLogLevel.debug:
        writer.writeByte(0);
        break;
      case AuditLogLevel.info:
        writer.writeByte(1);
        break;
      case AuditLogLevel.warning:
        writer.writeByte(2);
        break;
      case AuditLogLevel.error:
        writer.writeByte(3);
        break;
      case AuditLogLevel.critical:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AuditLogLevelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
