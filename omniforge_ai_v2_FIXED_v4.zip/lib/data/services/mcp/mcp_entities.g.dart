// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mcp_entities.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class McpToolEntityAdapter extends TypeAdapter<McpToolEntity> {
  @override
  final int typeId = 60;

  @override
  McpToolEntity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return McpToolEntity(
      id: fields[0] as String,
      name: fields[1] as String,
      displayName: fields[2] as String,
      description: fields[3] as String,
      endpoint: fields[4] as String,
      transport: fields[5] as McpToolTransport,
      requiredPermissions: (fields[6] as List).cast<McpToolPermission>(),
      config: (fields[7] as Map).cast<String, dynamic>(),
      status: fields[8] as McpToolStatus,
      installedAt: fields[9] as DateTime,
      lastUsedAt: fields[10] as DateTime?,
      usageCount: fields[11] as int,
    );
  }

  @override
  void write(BinaryWriter writer, McpToolEntity obj) {
    writer
      ..writeByte(12)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.displayName)
      ..writeByte(3)
      ..write(obj.description)
      ..writeByte(4)
      ..write(obj.endpoint)
      ..writeByte(5)
      ..write(obj.transport)
      ..writeByte(6)
      ..write(obj.requiredPermissions)
      ..writeByte(7)
      ..write(obj.config)
      ..writeByte(8)
      ..write(obj.status)
      ..writeByte(9)
      ..write(obj.installedAt)
      ..writeByte(10)
      ..write(obj.lastUsedAt)
      ..writeByte(11)
      ..write(obj.usageCount);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is McpToolEntityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class McpToolPermissionAdapter extends TypeAdapter<McpToolPermission> {
  @override
  final int typeId = 61;

  @override
  McpToolPermission read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return McpToolPermission.filesystem;
      case 1:
        return McpToolPermission.network;
      case 2:
        return McpToolPermission.process;
      case 3:
        return McpToolPermission.secrets;
      case 4:
        return McpToolPermission.userData;
      default:
        return McpToolPermission.filesystem;
    }
  }

  @override
  void write(BinaryWriter writer, McpToolPermission obj) {
    switch (obj) {
      case McpToolPermission.filesystem:
        writer.writeByte(0);
        break;
      case McpToolPermission.network:
        writer.writeByte(1);
        break;
      case McpToolPermission.process:
        writer.writeByte(2);
        break;
      case McpToolPermission.secrets:
        writer.writeByte(3);
        break;
      case McpToolPermission.userData:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is McpToolPermissionAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class McpToolStatusAdapter extends TypeAdapter<McpToolStatus> {
  @override
  final int typeId = 62;

  @override
  McpToolStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return McpToolStatus.available;
      case 1:
        return McpToolStatus.installed;
      case 2:
        return McpToolStatus.enabled;
      case 3:
        return McpToolStatus.disabled;
      case 4:
        return McpToolStatus.error;
      default:
        return McpToolStatus.available;
    }
  }

  @override
  void write(BinaryWriter writer, McpToolStatus obj) {
    switch (obj) {
      case McpToolStatus.available:
        writer.writeByte(0);
        break;
      case McpToolStatus.installed:
        writer.writeByte(1);
        break;
      case McpToolStatus.enabled:
        writer.writeByte(2);
        break;
      case McpToolStatus.disabled:
        writer.writeByte(3);
        break;
      case McpToolStatus.error:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is McpToolStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class McpToolTransportAdapter extends TypeAdapter<McpToolTransport> {
  @override
  final int typeId = 63;

  @override
  McpToolTransport read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return McpToolTransport.websocket;
      case 1:
        return McpToolTransport.http;
      case 2:
        return McpToolTransport.stdio;
      default:
        return McpToolTransport.websocket;
    }
  }

  @override
  void write(BinaryWriter writer, McpToolTransport obj) {
    switch (obj) {
      case McpToolTransport.websocket:
        writer.writeByte(0);
        break;
      case McpToolTransport.http:
        writer.writeByte(1);
        break;
      case McpToolTransport.stdio:
        writer.writeByte(2);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is McpToolTransportAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
